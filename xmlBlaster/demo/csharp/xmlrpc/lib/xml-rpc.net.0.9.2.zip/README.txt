XML-RPC.NET - XML-RPC for .NET 
v0.9.2
Copyright (C) 2001-2005 Charles Cook (chascook@gmail.com)

xmlrpcgen 
Copyright (C) 2003 Joe Bork

License is MIT X11.

For more information about XML-RPC refer to http://www.xmlrpc.com/

PREQUISITES
-----------
.NET Runtime 1.0 or 1.1


DOCUMENTATION
-------------
Open index.html in a web-browser
